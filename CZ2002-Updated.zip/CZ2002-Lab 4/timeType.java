public enum timeType{
    All,
    Odd,
    Even;

}