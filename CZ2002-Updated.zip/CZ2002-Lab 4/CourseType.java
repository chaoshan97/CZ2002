public enum CourseType  {
    GER_PE_STS,
    GER_PE_BM,
    GER_PE_LA,
    UE,
    CORE,
    MPE,
    GER_CORE;
}