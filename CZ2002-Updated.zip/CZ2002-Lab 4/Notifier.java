public interface Notifier {
    public void notify(String subject, String content, String recepients);
}
