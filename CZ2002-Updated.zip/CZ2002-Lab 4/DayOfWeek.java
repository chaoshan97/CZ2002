public enum DayOfWeek{
    MON,
    TUE,
    WED,
    THURS,
    FRI,
    SAT;
}